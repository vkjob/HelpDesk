﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using HelpDesk.Models;

namespace HelpDesk.Views
{
    public partial class MainWindow : Window
    {
        private List<Ticket> tickets;
        public MainWindow()
        {
            InitializeComponent();

            string currentDate = DateTime.Now.ToString("dd.MM.yyyy");
            CurrentUserTextBlock.Text = $"{currentDate} | Пользователь: admin";

            //var testTickets = new List<Ticket>
            tickets = new List<Ticket>

            {
                new Ticket
                {
                    Id = 1,
                    Category = "Сеть",
                    Description = "Нет доступа в Интернет с нового компьютера",
                    Priority = "Высокий",
                    Status = "В работе",
                    CreatedAt = new DateTime(2026, 11, 01, 14, 30, 0)
                },

                new Ticket
                {
                    Id = 2,
                    Category = "Программное обеспечение",
                    Description = "Не запускается Microsoft Word",
                    Priority = "Средний",
                    Status = "Новая",
                    CreatedAt = new DateTime(2026, 11, 02, 09, 01, 35)
                },

                new Ticket
                {
                    Id = 3,
                    Category = "Оборудование",
                    Description = "Не работает принтер",
                    Priority = "Низкий",
                    Status = "Выполнена",
                    CreatedAt = new DateTime(2026, 11, 03, 16, 54, 47)
                    //CreatedAt = DateTime.Now
                },

                new Ticket
                {
                    Id = 4,
                    Category = "Оборудование",
                    Description = "Не работает сканер",
                    Priority = "Низкий",
                    Status = "Новая",
                    CreatedAt = new DateTime(2026, 11, 06, 10, 23, 12)
                }
            };

            //TicketsDataGrid.ItemsSource = testTickets;
            TicketsDataGrid.ItemsSource = tickets;
        }

        private void AddTicketButton_Click(object sender, RoutedEventArgs e)
        {
            TicketCreateWindow window = new TicketCreateWindow();
            window.Owner = this;
            window.ShowDialog();
        }

        private void OpenEditWindow()
        {            
            if (TicketsDataGrid.SelectedItem == null)
            {
                MessageBox.Show(
                    "Сначала выберите заявку.",
                    "Редактирование",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            Ticket selectedTicket =
                TicketsDataGrid.SelectedItem as Ticket;

            if (selectedTicket == null)
            {
                MessageBox.Show(
                    "Не удалось получить данные выбранной заявки.",
                    "Ошибка",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);

                return;
            }

            TicketEditWindow window =
                new TicketEditWindow(selectedTicket);

            window.Owner = this;

            bool? result = window.ShowDialog();

            if (result == true)
            {
                TicketsDataGrid.Items.Refresh();
            }
        }


        private void EditTicketButton_Click(object sender, RoutedEventArgs e)
        {
            OpenEditWindow();
        }

        private void TicketsList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            // Проверяем, что клик был именно по строке, а не по пустому месту или заголовку таблицы
            if (e.OriginalSource is DependencyObject source)
            {
                // Ищем, принадлежит ли кликнутый элемент строке DataGridRow
                var row = ItemsControl.ContainerFromElement((ItemsControl)sender, source);
                if (row != null)
                {
                    OpenEditWindow();
                }
            }
        }

        private void DeleteTicketButton_Click(object sender, RoutedEventArgs e)
        {
            // Проверяем наличие выбранной строки
            if (TicketsDataGrid.SelectedItem == null)
            {
                MessageBox.Show(
                    "Выберите заявку для удаления.",
                    "Удаление",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            // Просим подтверждение
            MessageBoxResult result =
                MessageBox.Show(
                    "Вы действительно хотите удалить выбранную заявку?",
                    "Подтверждение удаления",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                MessageBox.Show(
                    "На следующих занятиях здесь будет выполняться " +
                    "удаление записи из MS SQL Server.",
                    "HelpDesk",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result =
                MessageBox.Show(
                    "Выйти из учётной записи?",
                    "HelpDesk",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

            if (result != MessageBoxResult.Yes)
            {
                return;
            }

            LoginWindow loginWindow =
                new LoginWindow();

            loginWindow.Show();

            Close();
        }

        //private List<Ticket> tickets = new List<Ticket>();
       
        private void ResetFilterButton_Click(object sender, RoutedEventArgs e)
        {
            SearchTextBox.Clear();

            StatusComboBox.SelectedIndex = 0;

            TicketsDataGrid.ItemsSource = tickets;
        }


        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            FilterTickets();
        }

        private void StatusComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            FilterTickets();
        }

        private void FilterTickets()
        {
            // Защита от запуска во время InitializeComponent()
            if (tickets == null)
            {
                return;
            }

            // 1. Получаем текст поиска
            string searchText = SearchTextBox.Text.Trim().ToLower();

            // 2. Получаем выбранный статус из ComboBox
            string selectedStatus = "Все";
            if (StatusComboBox.SelectedItem is ComboBoxItem selectedItem)
            {
                selectedStatus = selectedItem.Content.ToString();
            }

            // 3. Фильтруем список одновременно по двум условиям
            var result = tickets.Where(ticket =>
            {
                // Условие 1: подходит ли под текстовый поиск (если строка пустая — подходят все)
                bool matchesSearch = string.IsNullOrEmpty(searchText) ||
                                     ticket.Description.ToLower().Contains(searchText) ||
                                     ticket.Status.ToLower().Contains(searchText) ||
                                     ticket.Category.ToLower().Contains(searchText);

                // Условие 2: подходит ли под выбранный статус (если выбрано "Все" — подходят все)
                bool matchesStatus = (selectedStatus == "Все") ||
                                     (ticket.Status == selectedStatus);

                // Заявка попадёт в таблицу, только если выполнены ОБА условия
                return matchesSearch && matchesStatus;
            }).ToList();

            TicketsDataGrid.ItemsSource = result;
        }


        private void SearchButton_Click_OLD(object sender, RoutedEventArgs e)
        {
            string searchText =
                SearchTextBox.Text.Trim().ToLower();

            var result = tickets
                .Where(ticket =>
                    ticket.Description
                        .ToLower()
                        .Contains(searchText) ||
                    ticket.Status
                        .ToLower()
                        .Contains(searchText) ||
                    ticket.Category
                        .ToLower()
                        .Contains(searchText))
                .ToList();

            TicketsDataGrid.ItemsSource = result;
        }

        private void StatusComboBox_SelectionChanged_OLD(object sender, SelectionChangedEventArgs e)
        {
            // Защита от ошибки при запуске окна, когда список tickets ещё не заполнен
            if (tickets == null)
            {
                return;
            }

            // Получаем текст выбранного ComboBoxItem
            ComboBoxItem selectedItem = StatusComboBox.SelectedItem as ComboBoxItem;
            if (selectedItem == null)
            {
                return;
            }

            string selectedStatus = selectedItem.Content.ToString();

            // Если выбрано "Все" — показываем весь исходный список
            if (selectedStatus == "Все")
            {
                TicketsDataGrid.ItemsSource = tickets;
            }
            else
            {
                // Фильтруем заявки по выбранному статусу
                var result = tickets
                    .Where(ticket => ticket.Status == selectedStatus)
                    .ToList();

                TicketsDataGrid.ItemsSource = result;
            }
        }



    }
}
